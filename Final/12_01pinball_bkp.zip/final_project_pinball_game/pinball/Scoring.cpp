#include "Scoring.h"

Scoring::Scoring(){
  bonus = 1;
  score = 0;
  multiplier = 1;
  playerID = 0;
}

Scoring::Scoring(int id) {
  bonus = 0;
  //score = 0;
  score = 10; //Init non zero score to test display setting
  multiplier = 1;
  playerID = id;
}

void Scoring::addScore(long points) {
  score += points;
  Printf("Adding score for player %d\r\n", playerID);
  Printf("Score is %ld.\r\n", score);
  if(score > MAX_DISPLAY) score = MAX_DISPLAY;
}

void Scoring::calculateBonus(){

  if(bonus < 11) {
    score += bonus * multiplier * 1000;
  }
  else {
    score += multiplier * 20000;
    bonus = 11;
  }
  score += bonus * multiplier * 1000;
  if(score > MAX_DISPLAY) score = MAX_DISPLAY;
  bonus = 0;
  multiplier = 1;
}

void Scoring::advanceBonus() {
  bonus += (bonus == MAX_BONUS ? 0 : 1);
}

void Scoring::advanceMultiplier() {
  multiplier += (multiplier == MAX_MULTIPLIER ? 0 : 1);
  if(multiplier == 4) {
    multiplier ++;
  }
}

long Scoring::getPointsLong() {
  return score;
}

void Scoring::resetPoints(){
  score = 0;
}

int Scoring::getID(){
  return playerID;
}

int Scoring::getBonus() {
  return bonus;
}

int Scoring::getMultiplier() {
  return multiplier;
}

