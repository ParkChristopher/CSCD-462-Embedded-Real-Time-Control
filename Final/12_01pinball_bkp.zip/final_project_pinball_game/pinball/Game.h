#ifndef GAME_H
#define GAME_H

#include <BallyLib.h>
#include <Printf.h>
#include "Scoring.h"
#include "Switch.h"
#include "Light.h"

#define MAX_PLAYERS 4

class Game {

public:
  Game(Bally bally);
  void addPlayer();
	void initGame();
  void addCredit();
  void useCredit();
  
  Scoring* getCurrentPlayer();
  void setCurrentPlayer(int id);
  void updateScoreDisplays();
  void updateCreditDisplay();
  void blankDisplay(int disp);
  void resetDisplay(int disp);
  void resetPlayerPoints();
  unsigned int getCredits();
  unsigned int getNumPlayers();
  

private:
  Scoring players[MAX_PLAYERS];
  unsigned int nCredits;
  unsigned int nPlayers;
  int currentPlayer;
  Bally bally;
};

#endif //GAME_H
