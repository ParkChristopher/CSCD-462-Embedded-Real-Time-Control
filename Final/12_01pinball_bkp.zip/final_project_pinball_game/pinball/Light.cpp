
#include "Light.h"

void resetLights(Bally bally) {

  bally.setLamp(LIGHT_BONUS_1_2_3_4_ROW, LIGHT_BONUS_1K_COL, false);
  bally.setLamp(LIGHT_BONUS_1_2_3_4_ROW, LIGHT_BONUS_2K_COL, false);
  bally.setLamp(LIGHT_BONUS_1_2_3_4_ROW, LIGHT_BONUS_3K_COL, false);
  bally.setLamp(LIGHT_BONUS_1_2_3_4_ROW, LIGHT_BONUS_4K_COL, false);
  bally.setLamp(LIGHT_BONUS_5_6_7_8_ROW, LIGHT_BONUS_5K_COL, false);
  bally.setLamp(LIGHT_BONUS_5_6_7_8_ROW, LIGHT_BONUS_6K_COL, false);
  bally.setLamp(LIGHT_BONUS_5_6_7_8_ROW, LIGHT_BONUS_7K_COL, false);
  bally.setLamp(LIGHT_BONUS_5_6_7_8_ROW, LIGHT_BONUS_8K_COL, false);
  bally.setLamp(LIGHT_BONUS_9_10_20_ROW, LIGHT_BONUS_9K_COL, false);
  bally.setLamp(LIGHT_BONUS_9_10_20_ROW, LIGHT_BONUS_10K_COL, false);
  bally.setLamp(LIGHT_BONUS_9_10_20_ROW, LIGHT_BONUS_20K_COL, false);

  bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_A_LANE_COL, false);
  bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_B_LANE_COL, false);

  bally.setLamp(LIGHT_AB_LANE_1_2_3_4_SCORE_ROW, LIGHT_AB_LANE_1K_COL, false);
  bally.setLamp(LIGHT_AB_LANE_1_2_3_4_SCORE_ROW, LIGHT_AB_LANE_2K_COL, false);
  bally.setLamp(LIGHT_AB_LANE_1_2_3_4_SCORE_ROW, LIGHT_AB_LANE_3K_COL, false);
  bally.setLamp(LIGHT_AB_LANE_1_2_3_4_SCORE_ROW, LIGHT_AB_LANE_4K_COL, false);
  bally.setLamp(LIGHT_AB_LANE_5_SCORE_ROW, LIGHT_AB_LANE_5K_COL, false);

  bally.setLamp(LIGHT_EXTRA_BALL_ROW, LIGHT_EXTRA_BALL_COL, false);

  bally.setLamp(LIGHT_50K_BONUS_ROW, LIGHT_50K_BONUS_RIGHT_COL, false);
  bally.setLamp(LIGHT_50K_BONUS_ROW, LIGHT_50K_BONUS_LEFT_COL, false);

  bally.setLamp(LIGHT_BOP_BUMPER_1000_ROW, LIGHT_BOP_BUMPER_1000_RIGHT_COL, false);
  bally.setLamp(LIGHT_BOP_BUMPER_1000_ROW, LIGHT_BOP_BUMPER_1000_LEFT_COL, false);

  bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_2X_BONUS_COL, false);
  bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_3X_BONUS_COL, false);
  bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_5X_BONUS_COL, false);

  
  bally.setLamp(LIGHT_2_3_5_BONUS_HIGH_ROW, LIGHT_2X_BONUS_COL, false);
  bally.setLamp(LIGHT_2_3_5_BONUS_HIGH_ROW, LIGHT_3X_BONUS_COL, false);
  bally.setLamp(LIGHT_2_3_5_BONUS_HIGH_ROW, LIGHT_5X_BONUS_COL, false);

  bally.setLamp(LIGHT_SHOOT_AGAIN_ROW, LIGHT_SHOOT_AGAIN_BACKGLASS_COL, false);
  bally.setLamp(LIGHT_SHOOT_AGAIN_ROW, LIGHT_SHOOT_AGAIN_PLAYFIELD_COL, false);

  bally.setLamp(LIGHT_MATCH_ROW, LIGHT_MATCH_COL, false);
  bally.setLamp(LIGHT_CREDIT_ROW, LIGHT_CREDIT_COL, false);
  bally.setLamp(LIGHT_BALL_IN_PLAY_ROW, LIGHT_BALL_IN_PLAY_COL, false);

  bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_2X_BONUS_LOW_COL, false);
  bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_3X_BONUS_LOW_COL, false);
  bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_5X_BONUS_LOW_COL, false);

  bally.setLamp(LIGHT_GAME_OVER_ROW, LIGHT_GAME_OVER_COL, false);
  bally.setLamp(LIGHT_TILT_ROW, LIGHT_TILT_COL, false);

}
