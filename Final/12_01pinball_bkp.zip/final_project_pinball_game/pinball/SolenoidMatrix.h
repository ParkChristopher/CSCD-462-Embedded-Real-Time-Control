
#ifndef SOLENOIDMATRIX_H
#define SOLENOIDMATRIX_H

/**
 * Instantaious Solenoids
 */
#define HOLE 0
#define BUMP_100_LEFT 1
#define BELL_LOW 2
#define DROP_TARGET_LEFT 3
#define BELL_MID_HIGH 4
#define BUMP_1000_RIGHT 5
#define OUT_HOLE 6
#define DROP_TARGET_RIGHT 7
#define BELL_MID_LOW 8
#define BUMP_100_RIGHT 9
#define KNOCKER 10
#define SLINGSHOT_RIGHT 11
#define BELL_HIGH 12
#define SLINGSHOT_LEFT 13
#define BUMP_1000_LEFT 14

/**
 * Continuous Solenoids
 */
#define COIN_ACCEPT 1
#define FLIPPER_DISABLE 2

#endif //SOLENOIDMATRIX_H
