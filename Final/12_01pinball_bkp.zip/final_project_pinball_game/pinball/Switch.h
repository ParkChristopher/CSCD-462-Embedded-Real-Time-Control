
#ifndef SWITCH_H
#define SWITCH_H
  
#include <BallyLib.h>
#include <Printf.h>
#include "Game.h"
#include "Light.h"
#include "SolenoidMatrix.h"

class Game;

/**
 * Coin Switch Row and Col
 */
#define CR_ROW    0     // credit
#define CR_COL    5
#define COIN_ROW  1     // coin
#define COIN_COL  0

/**
 * Coin and Switch Values
 */
#define TEST_BUTTON 4
#define COIN_BUTTON 8
#define CREDIT_BUTTON 16

/**
 * Switch Row and Col
 */
#define TILT_ROW 0
#define TILT_COL 6

#define HOLE_OUT_ROW 0  // ball out of play
#define HOLE_OUT_COL 7

#define DROP_TARGET_ROW 2
#define DROP_TARGET_RIGHT_D_COL 0
#define DROP_TARGET_RIGHT_C_COL 1
#define DROP_TARGET_RIGHT_B_COL 2
#define DROP_TARGET_RIGHT_A_COL 3
#define DROP_TARGET_LEFT_D_COL 4
#define DROP_TARGET_LEFT_C_COL 5
#define DROP_TARGET_LEFT_B_COL 6
#define DROP_TARGET_LEFT_A_COL 7

#define FLIPPER_FEED_LANE_ROW 3
#define FLIPPER_FEED_LANE_RIGHT_COL 0
#define FLIPPER_FEED_LANE_LEFT_COL 1

#define DROP_TARGET_REBOUND_ROW 3
#define DROP_TARGET_REBOUND_COL 2

#define LANE_ROW 3
#define LANE_B_COL 3
#define LANE_A_COL 4
#define LANE_B_TOP_COL 5
#define LANE_A_TOP_COL 6

#define HOLE_KICK_ROW 3
#define HOLE_KICK_COL 7

#define OUT_LANE_ROW 4
#define OUT_LANE_RIGHT_COL 0
#define OUT_LANE_LEFT_COL 1

#define SLINGSHOT_ROW 4
#define SLINGSHOT_RIGHT_COL 2
#define SLINGSHOT_LEFT_COL 3

#define POP_BUMPER_ROW 4
#define POP_BUMPER_RED_RIGHT_COL 4
#define POP_BUMPER_RED_LEFT_COL 5
#define POP_BUMPER_YELLOW_RIGHT_COL 6
#define POP_BUMPER_YELLOW_LEFT_COL 7

class Switch {

public:
  void checkSwitches(Bally bally, Game* game);
  void resetSwitches();
  
private:
  bool aLaneLow;
  bool aLaneHigh;
  bool bLaneLow;
  bool bLaneHigh;
  int laneTimes;
  bool popBumper1000LitLeft;
  bool popBumper1000LitRight;
};

#endif //SWITCH_H
