#include "Game.h"


Game::Game(Bally bally) {
  
  bally = bally;
  nPlayers = 0;
  nCredits = 0;
}

void Game::addPlayer() {
  
  if(nPlayers < MAX_PLAYERS) {
    Printf("Num Players is: %d\r\n", nPlayers);
    bally.fireSolenoid(BELL_LOW, false);
    if(nPlayers > 0) bally.setLamp(LIGHT_CAN_PLAY_ROW, nPlayers - 1, false);
    bally.setLamp(LIGHT_CAN_PLAY_ROW, nPlayers, true);
    blankDisplay(nPlayers);
    resetDisplay(nPlayers);
    nPlayers++;
    Printf(F("Players: %d\r\n"), nPlayers);
  }
}

void Game::initGame() {
	bally.setContSolenoid(FLIPPER_DISABLE, true);

  for(int i = 0; i < MAX_PLAYERS; i ++){
    bally.setLamp(LIGHT_CAN_PLAY_ROW, i, false);
  }
	bally.setLamp(LIGHT_GAME_OVER_ROW, LIGHT_GAME_OVER_COL, true);
  nPlayers = 0;
}

void Game::addCredit() {
  nCredits++;

  //Limiting credits to max of 9 for now.
  if(nCredits > 9){
    nCredits = 9;
    return;
  }
  bally.setLamp(LIGHT_CREDIT_ROW, LIGHT_CREDIT_COL, true);
  updateCreditDisplay();
  bally.fireSolenoid(BELL_MID_LOW, false, false);
}

void Game::useCredit() {
  nCredits--;
  //At 0 credits turn off the credit indicator
  if(nCredits == 0) bally.setLamp(LIGHT_CREDIT_ROW, LIGHT_CREDIT_COL, false);
  updateCreditDisplay();
}

Scoring* Game::getCurrentPlayer() {
  return &players[currentPlayer];
}

void Game::setCurrentPlayer(int id){
  currentPlayer = id;
}

void Game::updateScoreDisplays() {
  int i, val, digit;
  long score;
  
  for(i = 0; i < nPlayers; i++){
    val = digit = 0;
    score = players[i].getPointsLong();
    
    while(score > 0) {
      val = score % 10;
      score = score / 10;
      bally.setDisplay(i, digit, val);
      digit ++;
    }
  }
}

void Game::blankDisplay(int disp){
  for (int i = 0; i < N_DIGITS; i++){
    bally.setDisplay(disp, i, 10);
  }
}

void Game::resetDisplay(int disp){
  //for(int i = 0; i < N_DIGITS; i++){
    bally.setDisplay(disp, 0, 0);
  //}
}

void Game::resetPlayerPoints(){
  for(int i = 0; i < nPlayers; i++){
    players[i].resetPoints();
  }
}

void Game::updateCreditDisplay() {
  bally.setDisplay(4, 3, nCredits);
}

unsigned int Game::getCredits() {
  return nCredits;
}

unsigned int Game::getNumPlayers() {
  return nPlayers;
}
