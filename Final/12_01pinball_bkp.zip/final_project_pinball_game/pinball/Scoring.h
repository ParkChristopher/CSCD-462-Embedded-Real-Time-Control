
#ifndef SCORING_H
#define SCORING_H

#include <BallyLib.h>
#include <Printf.h>

#define SCORE_SAUCER 3000
#define SCORE_YELLOW_BUMPER 100
#define SCORE_RED_BUMPER 1000
#define SCORE_DROP_TARGET 500
#define SCORE_DROP_TARGET_RESET 2000
#define SCORE_FLIPPER_FEED_LANE 500
#define SCORE_OUT_LANE 1000

#define MAX_BONUS 11
#define MAX_MULTIPLIER 5
#define MAX_DISPLAY 999999

class Scoring {

public:
  Scoring();
  Scoring(int id);
  void addScore(long points);
  void advanceBonus();
  void advanceMultiplier();
  void calculateBonus();
  long getPointsLong();
  void resetPoints();
  int getID();
  int getMultiplier();
  int getBonus();
  

private:
  long score;
  int multiplier;
  int bonus;
  int playerID;
};

#endif //SCORING_H
