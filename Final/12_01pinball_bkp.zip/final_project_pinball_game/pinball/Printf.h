#include  <Arduino.h>
#include  <stdarg.h>     // for va_xxx
#include  <stdlib.h>      // for vsnprintf
void Printf(char *fmt, ... ) ;
void Printf(const __FlashStringHelper *fmt, ... ) ;

