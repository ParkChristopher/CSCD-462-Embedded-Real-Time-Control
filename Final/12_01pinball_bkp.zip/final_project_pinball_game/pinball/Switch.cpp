
#include "Switch.h"

void Switch::checkSwitches(Bally bally, Game* game) {

  int drop_target_left_count = 0;
  int drop_target_right_count = 0;
  Scoring* player = game->getCurrentPlayer();

  // tilt
  if(bally.getSwitch(TILT_ROW, TILT_COL)) {
    bally.setContSolenoid(FLIPPER_DISABLE, true);
  }

  // kick hole
  if(bally.getRedge(HOLE_KICK_ROW, HOLE_KICK_COL)) {
    int i;
    int usec = 10; // approximate delay in milliseconds
    // todo make delay at 1000 work

    for(i = 0; i < usec && bally.getSwitch(HOLE_KICK_ROW, HOLE_KICK_COL); i ++) {
      delay(1);
    }
    if(i == usec) {
      bally.fireSolenoid(HOLE, true);
      bally.fireSolenoid(BELL_HIGH, true);
      player->addScore(SCORE_SAUCER);
      player->advanceMultiplier();
    }
    // else the ball bounced out
  }

  // pop bumpers
  if(bally.getSwitch(POP_BUMPER_ROW, POP_BUMPER_YELLOW_LEFT_COL)) {
    bally.fireSolenoid(BUMP_100_LEFT, true);
    bally.fireSolenoid(BELL_MID_HIGH, true);
    player->addScore(SCORE_YELLOW_BUMPER);
  }
  if(bally.getSwitch(POP_BUMPER_ROW, POP_BUMPER_YELLOW_RIGHT_COL)) {
    bally.fireSolenoid(BUMP_100_RIGHT, true);
    bally.fireSolenoid(BELL_MID_HIGH, true);
    player->addScore(SCORE_YELLOW_BUMPER);
  }
  if(bally.getSwitch(POP_BUMPER_ROW, POP_BUMPER_RED_LEFT_COL)) {
    bally.fireSolenoid(BUMP_1000_LEFT, true);
    bally.fireSolenoid(BELL_MID_LOW, true);
    if(popBumper1000LitLeft) {
      player->addScore(SCORE_RED_BUMPER);
    }
  }
  if(bally.getSwitch(POP_BUMPER_ROW, POP_BUMPER_RED_RIGHT_COL)) {
    bally.fireSolenoid(BUMP_1000_RIGHT, true);
    bally.fireSolenoid(BELL_MID_LOW, true);
    if(popBumper1000LitRight) {
      player->addScore(SCORE_RED_BUMPER);
    }
  }

  // drop targets todo updated drop target logic
  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_LEFT_A_COL)) {
    bally.fireSolenoid(BELL_HIGH, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_LEFT_B_COL)) {
    bally.fireSolenoid(BELL_MID_HIGH, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_LEFT_C_COL)) {
    bally.fireSolenoid(BELL_MID_LOW, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_LEFT_D_COL)) {
    bally.fireSolenoid(BELL_LOW, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if(bally.getSwitchRow(DROP_TARGET_ROW) >> 4 == 15) {
    bally.fireSolenoid(BELL_LOW, true);
    bally.fireSolenoid(DROP_TARGET_LEFT, true);
    delay(30); // todo delay without blocking
    // todo set 50k bonus light, or add bonus score
    player->advanceBonus();
    player->addScore(50000);
  }

  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_RIGHT_A_COL)) {
    bally.fireSolenoid(BELL_HIGH, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_RIGHT_B_COL)) {
    bally.fireSolenoid(BELL_MID_HIGH, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_RIGHT_C_COL)) {
    bally.fireSolenoid(BELL_MID_LOW, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if(bally.getRedge(DROP_TARGET_ROW, DROP_TARGET_RIGHT_D_COL)) {
    bally.fireSolenoid(BELL_LOW, true);
    player->addScore(SCORE_DROP_TARGET);
  }
  if((bally.getSwitchRow(DROP_TARGET_ROW) & 15) == 15) {
    bally.fireSolenoid(BELL_LOW, true);
    bally.fireSolenoid(DROP_TARGET_RIGHT, true);
    delay(30); // todo delay without blocking
    // todo set 50k bonus light, or add bonus score
    player->advanceBonus();
    player->addScore(50000);
  }

  // slingshots
  if(bally.getSwitch(SLINGSHOT_ROW, SLINGSHOT_LEFT_COL)) {
    bally.fireSolenoid(SLINGSHOT_LEFT, false);
    bally.fireSolenoid(BELL_MID_HIGH, true);
  }
  if(bally.getSwitch(SLINGSHOT_ROW, SLINGSHOT_RIGHT_COL)) {
    bally.fireSolenoid(SLINGSHOT_RIGHT, false);
    bally.fireSolenoid(BELL_MID_HIGH, true);
  }

  // flipper feed lanes
  if(bally.getRedge(FLIPPER_FEED_LANE_ROW, FLIPPER_FEED_LANE_LEFT_COL)
     || bally.getRedge(FLIPPER_FEED_LANE_ROW, FLIPPER_FEED_LANE_RIGHT_COL)) {
      bally.fireSolenoid(BELL_MID_HIGH, true);
      delay(30);
      bally.fireSolenoid(BELL_MID_LOW, true);
    player->addScore(SCORE_FLIPPER_FEED_LANE);
    player->advanceBonus();
  }

  if(bally.getRedge(OUT_LANE_ROW, OUT_LANE_LEFT_COL)
     || bally.getRedge(OUT_LANE_ROW, OUT_LANE_RIGHT_COL)) {
      bally.fireSolenoid(BELL_HIGH, true);
      delay(30);
      bally.fireSolenoid(BELL_LOW, true);
    player->addScore(SCORE_OUT_LANE);

  }

  // AB lanes
  if(bally.getDebRedge(LANE_ROW, LANE_A_COL)) {
    bally.fireSolenoid(BELL_MID_HIGH, true);
    aLaneLow = true;
    bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_A_LANE_COL, true);
    player->advanceBonus();
  }
  if(bally.getDebRedge(LANE_ROW, LANE_A_TOP_COL)) {
    bally.fireSolenoid(BELL_HIGH, true);
    aLaneHigh = true;
    bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_A_LANE_COL, true);
    player->advanceBonus();
  }
  if(bally.getDebRedge(LANE_ROW, LANE_B_COL)) {
    bally.fireSolenoid(BELL_HIGH, true);
    bLaneLow = true;
    bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_B_LANE_COL, true);
    player->advanceBonus();
  }
  if(bally.getDebRedge(LANE_ROW, LANE_B_TOP_COL)) {
    bally.fireSolenoid(BELL_MID_HIGH, true);
    bLaneHigh = true;
    bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_B_LANE_COL, true);
    player->advanceBonus();
  }
  // light bop bumpers
  if(aLaneLow && bLaneLow && aLaneHigh && bLaneHigh) {
    laneTimes += laneTimes == 2 ? 0 : 1; 
    //We only ever light the left red bumper here.....
    bally.setLamp(LIGHT_BOP_BUMPER_1000_ROW, LIGHT_BOP_BUMPER_1000_LEFT_COL, true);

    aLaneLow = false;
    aLaneHigh = false;
    bLaneLow = false;
    bLaneHigh = false;

    bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_A_LANE_COL, false);
    bally.setLamp(LIGHT_AB_LANES_ROW, LIGHT_B_LANE_COL, false);
  }
  if(laneTimes == 1) {
    popBumper1000LitLeft = true;
    bally.setLamp(LIGHT_BOP_BUMPER_1000_ROW, LIGHT_BOP_BUMPER_1000_LEFT_COL, true);
  }
  else if(laneTimes == 2) {
    popBumper1000LitRight = true;
    bally.setLamp(LIGHT_BOP_BUMPER_1000_ROW, LIGHT_BOP_BUMPER_1000_RIGHT_COL, true);
  }

  // set bonus lights
  int bonus = player->getBonus();
  if(bonus < 5) {
    bally.setLamp(LIGHT_BONUS_1_2_3_4_ROW, bonus - 1, true);
  }
  else if(bonus < 9) {
    bally.setLamp(LIGHT_BONUS_5_6_7_8_ROW, (bonus - 1) % 4, true);
  }
  else if(bonus < 12) {
    bally.setLamp(LIGHT_BONUS_9_10_20_ROW, (bonus - 1) % 4, true);
  }

  // set multiplier light
  int multiplier = player->getMultiplier();
  if(multiplier > 1) {

    bally.setLamp(LIGHT_2_3_5_BONUS_ROW, LIGHT_2X_BONUS_COL, false);
    bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_2X_BONUS_COL, false);
    bally.setLamp(LIGHT_2_3_5_BONUS_ROW, LIGHT_3X_BONUS_COL, false);
    bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_3X_BONUS_LOW_COL, false);
    bally.setLamp(LIGHT_2_3_5_BONUS_ROW, LIGHT_5X_BONUS_COL, false);
    bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_5X_BONUS_LOW_COL, false);

    switch (multiplier) {
      case 2:
        bally.setLamp(LIGHT_2_3_5_BONUS_ROW, LIGHT_2X_BONUS_COL, true);
        bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_2X_BONUS_COL, true);
        break;
      case 3:
        bally.setLamp(LIGHT_2_3_5_BONUS_ROW, LIGHT_3X_BONUS_COL, true);
        bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_3X_BONUS_LOW_COL, true);
        break;
      case 5:
        bally.setLamp(LIGHT_2_3_5_BONUS_ROW, LIGHT_5X_BONUS_COL, true);
        bally.setLamp(LIGHT_2_3_5_BONUS_LOW_ROW, LIGHT_5X_BONUS_LOW_COL, true);
        break;
    }
  }
}

void Switch::resetSwitches() {
  aLaneLow = false;
  aLaneHigh = false;
  bLaneLow = false;
  bLaneHigh = false;
  laneTimes = 0;
  popBumper1000LitLeft = false;
  popBumper1000LitRight = false;
}
